package models;

import java.sql.*;

public class Post {
    public int postid;
    public String title;
    public String body;
    public Timestamp modified;
    public Timestamp created;
}
